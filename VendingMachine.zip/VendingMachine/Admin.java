import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.*;
import java.util.*;
import java.util.List;
import java.awt.event.WindowEvent;

class DrinksTableModel extends AbstractTableModel {
    private List<Drink> drinksList;

    public DrinksTableModel(List<Drink> drinksList) {
        this.drinksList = drinksList;
    }

    @Override
    public int getRowCount() {
        return drinksList.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Name";
            case 1:
                return "Price ($)";
            case 2:
                return "Quantity";
            default:
                return "";
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Drink drink = drinksList.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return drink.name;
            case 1:
                return drink.price;
            case 2:
                return drink.quantity;
            default:
                return null;
        }
    }

    @Override
    public void setValueAt(Object value, int rowIndex, int columnIndex) {
        Drink drink = drinksList.get(rowIndex);
        switch (columnIndex) {
            case 0:
                drink.name = (String) value;
                break;
            case 1:
                drink.price = (Double) value;
                break;
            case 2:
                drink.quantity = (Integer) value;
                break;
        }
        fireTableCellUpdated(rowIndex, columnIndex);
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return true;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        switch (columnIndex) {
            case 0:
                return String.class;
            case 1:
                return Double.class;
            case 2:
                return Integer.class;
            default:
                return Object.class;
        }
    }
}

public class Admin {
    private static JFrame frame;
    private static JTextField usernameField;
    private static JPanel drinksTablePanel;
    private JPasswordField passwordField;
    private JButton signupButton;
    private JButton loginButton;

    private static final String STAFF_FILE = "staff.txt";
    private static final String DRINKS_FILE = "drinks.txt";
    private static List<Drink> drinksList = new ArrayList<>();

    public Admin() {
        frame = new JFrame("Admin Login/Signup");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                logActivity.logSystemEndActivity();
                System.exit(0); // Exit the application
            }
        });
        
        JPanel loginPanel = createLoginPanel();
        frame.add(loginPanel, BorderLayout.CENTER);
    
        frame.setVisible(true);
    }
    
    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Create and style labels
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gbc.anchor = GridBagConstraints.WEST;
        panel.add(usernameLabel, gbc);
        
        gbc.gridy++;
        usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 16));
        panel.add(usernameField, gbc);
        
        gbc.gridy++;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(passwordLabel, gbc);
        
        gbc.gridy++;
        passwordField = new JPasswordField(20);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 16));
        panel.add(passwordField, gbc);
        
        gbc.gridy++;
        JPanel buttonPanel = new JPanel();
        
        // Create and style login button
        loginButton = new JButton("Log In");
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.addActionListener(e -> login());
        buttonPanel.add(loginButton);
        
        // Create and style signup button
        signupButton = new JButton("Sign Up");
        signupButton.setFont(new Font("Arial", Font.BOLD, 16));
        signupButton.addActionListener(e -> signup());
        buttonPanel.add(signupButton);
        
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(buttonPanel, gbc);
        
        return panel;
    }

    private void signup() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        if (!username.isEmpty() && !password.isEmpty()) {
            // Write admin data to staff.txt in CSV format
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(STAFF_FILE, true))) {
                writer.write(username + "," + password);
                writer.newLine();
                writer.flush();
                JOptionPane.showMessageDialog(frame, "Admin account created successfully!");
                usernameField.setText("");
                passwordField.setText("");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(frame, "Error creating admin account.");
                usernameField.setText("");
                passwordField.setText("");
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Please enter valid username and password.");
        }
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
    
        boolean validCredentials = false;
        try (BufferedReader reader = new BufferedReader(new FileReader(STAFF_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2 && parts[0].equals(username) && parts[1].equals(password)) {
                    validCredentials = true;
                    break;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading staff data.");
        }
    
        if (validCredentials) {
            logActivity.logAdminLoginActivity(username); // Log the login activity
            frame.dispose();
            showAdminMenu();
        } else {
            JOptionPane.showMessageDialog(null, "Invalid admin credentials.");
            // Clear input fields
            usernameField.setText("");
            passwordField.setText("");
        }
    }
    

    private static class QuantityCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(
                JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component cell = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    
            int quantity = (int) value; // Get the quantity value
    
            if (quantity == 0) {
                cell.setBackground(Color.RED);
            } else if (quantity > 0 && quantity <= 10) {
                cell.setBackground(Color.ORANGE);
            } else {
                cell.setBackground(Color.GREEN);
            }
            
            setHorizontalAlignment(JLabel.CENTER); // Center align the content
    
            return cell;
        }
    }
        

    private static void showDrinksTable(JPanel panel) {
    loadDrinksData();
    DrinksTableModel tableModel = new DrinksTableModel(drinksList);
    JTable table = new JTable(tableModel);

    // Increase the font size and set row height
    Font tableFont = new Font("Arial", Font.PLAIN, 14);
    table.setFont(tableFont);
    table.setRowHeight(25);

    // Increase the font size of the table header (column headers)
    JTableHeader tableHeader = table.getTableHeader();
    Font headerFont = new Font("Arial", Font.BOLD, 18);
    tableHeader.setFont(headerFont);

    // Apply renderer to center align all columns
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    for (int i = 0; i < table.getColumnCount(); i++) {
        table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }
    table.getColumnModel().getColumn(2).setCellRenderer(new QuantityCellRenderer()); // Custom renderer for quantity column

    // Attach a table cell listener to detect changes in the table cells
    table.getModel().addTableModelListener(e -> {
        int row = e.getFirstRow();
        int column = e.getColumn();
        if (column != -1) { // Check if a specific column was edited
            DrinksTableModel model = (DrinksTableModel) e.getSource();
            String columnName = model.getColumnName(column);
            Object newValue = model.getValueAt(row, column);

            if (columnName.equals("Name")) {
                drinksList.get(row).name = (String) newValue;
            } else if (columnName.equals("Price")) {
                drinksList.get(row).price = (double) newValue;
            } else if (columnName.equals("Quantity")) {
                drinksList.get(row).quantity = (int) newValue;
            }

            saveDrinksData(); // Save the changes when a cell is edited
        }
    });

    JScrollPane scrollPane = new JScrollPane(table);

    panel.removeAll();
    panel.add(scrollPane, BorderLayout.CENTER);
    panel.revalidate();
    panel.repaint();
}

    private static void showAdminMenu() {
        JPanel menuPanel = new JPanel(new BorderLayout());

        if (drinksTablePanel == null) {
            drinksTablePanel = new JPanel(new BorderLayout());
            showDrinksTable(drinksTablePanel);
        }

        // Create a panel for login log
        JTextArea LogTextArea = new JTextArea(10, 30);
        LogTextArea.setEditable(false);
        JScrollPane LogScrollPane = new JScrollPane(LogTextArea);
        loadLog(LogTextArea); // Load login log data

        // Add drinks table and login log to the main menu panel
        menuPanel.add(drinksTablePanel, BorderLayout.NORTH);
        menuPanel.add(LogScrollPane, BorderLayout.SOUTH);

        String[] options = {
            "Add Drink",
            "Modify Drink",
            "Delete Drink",
            "View All Orders",
            "Generate Reports",
            "Account Management",
            "Logout"
        };

        int choice = JOptionPane.showOptionDialog(frame,
                menuPanel,
                "Admin Menu",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                options,
                options[0]
        );

        switch (choice) {
            case 0:
                addDrinks();
                break;
            case 1:
                modifyDrinks();
                break;
            case 2:
                deleteDrinks();
                break;
            case 3:
                viewAllOrders();
                break;
            case 4:
                generateReports();
                break;
            case 5:
                showAccountManagementPanel();
                break;
            case 6:
                frame.dispose();
                menuPanel.removeAll();
                VendingMachineGUI.createAndShowGUI();
                break; 
        }
    }
    
    private static void loadLog(JTextArea LogTextArea) {
        try (BufferedReader reader = new BufferedReader(new FileReader("log.txt"))) {
            StringBuilder LogText = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                LogText.append(line).append("\n");
            }
    
            LogTextArea.setText(LogText.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error loading login log data.");
        }
    }
    
    
    private static void addDrinks() {
        String name = JOptionPane.showInputDialog(frame, "Enter the name of the new drink:");
        
        if (name != null && !name.isEmpty()) {
            double price = Double.parseDouble(JOptionPane.showInputDialog(frame, "Enter the price of the new drink:"));
            int quantity = Integer.parseInt(JOptionPane.showInputDialog(frame, "Enter the initial quantity of the new drink:"));
            
            drinksList.add(new Drink(name, price, quantity));
            saveDrinksData();
        
            JOptionPane.showMessageDialog(frame, "New drink added successfully!");
            showAdminMenu();
        } else {
            JOptionPane.showMessageDialog(frame, "Invalid input. Please try again.");
            showAdminMenu();
        }
    }

    
    
    private static void modifyDrinks() {
        String[] drinkNames = getDrinkNamesArray();
        
        if (drinkNames.length == 0) {
            JOptionPane.showMessageDialog(frame,"No drinks available to modify.");
            return;
        }
        
        String selectedDrink = (String) JOptionPane.showInputDialog(frame,
            "Select the drink to modify:",
            "Modify Drinks",
            JOptionPane.PLAIN_MESSAGE,
            null,
            drinkNames,
            drinkNames[0]
        );
    
        if (selectedDrink != null) {
            String newName = JOptionPane.showInputDialog("Enter the new name for the drink:");
            double newPrice = Double.parseDouble(JOptionPane.showInputDialog("Enter the new price for the drink:"));
            int newQuantity = Integer.parseInt(JOptionPane.showInputDialog("Enter the new quantity for the drink:"));
    
            for (Drink drink : drinksList) {
                if (drink.name.equals(selectedDrink)) {
                    drink.name = newName;
                    drink.price = newPrice;
                    drink.quantity = newQuantity;
                    break;
                }
            }
            saveDrinksData();
            JOptionPane.showMessageDialog(frame,"Drink modified successfully!");
            showAdminMenu();
        }
    }

    private static void deleteDrinks() {
        String[] drinkNames = getDrinkNamesArray();
    
        if (drinkNames.length == 0) {
            JOptionPane.showMessageDialog(frame,"No drinks available to delete.");
            return;
        }
    
        String selectedDrink = (String) JOptionPane.showInputDialog(frame,
            "Select the drink to delete:",
            "Delete Drinks",
            JOptionPane.PLAIN_MESSAGE,
            null,
            drinkNames,
            drinkNames[0]
        );
    
        if (selectedDrink != null) {
            // Remove the selected drink from the drinksList
            drinksList.removeIf(drink -> drink.name.equals(selectedDrink));
    
            // Update the drinks.txt file
            saveDrinksData();
    
            JOptionPane.showMessageDialog(frame, "Drink deleted successfully!");
            showAdminMenu();
        }
    }
    
    private static void saveDrinksData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DRINKS_FILE))) {
            for (Drink drink : drinksList) {
                writer.write(drink.name + "," + drink.price + "," + drink.quantity);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error updating drinks data.");
        }
    }

    private static String[] getDrinkNamesArray() {
        String[] drinkNames = new String[drinksList.size()];
        for (int i = 0; i < drinksList.size(); i++) {
            drinkNames[i] = drinksList.get(i).name;
        }
        return drinkNames;
    }

    private static void viewAllOrders() {
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            JPanel panel = new JPanel();
            panel.setLayout(new BorderLayout());
    
            DefaultTableModel tableModel = new DefaultTableModel();
            tableModel.addColumn("Order");
            tableModel.addColumn("Total Cost");
    
            String line;
            int orderNumber = 1;
            double totalCost = 0.0;
    
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Total Cost:")) {
                    totalCost = Double.parseDouble(line.substring("Total Cost:".length()).trim().replace("$", ""));
                    tableModel.addRow(new String[]{"Order " + orderNumber, "$" + totalCost});
                    orderNumber++;
                }
            }
    
            JTable ordersTable = new JTable(tableModel);
            JScrollPane scrollPane = new JScrollPane(ordersTable);
    
            JButton viewOrderButton = new JButton("View Selected Order");
            viewOrderButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int selectedRow = ordersTable.getSelectedRow();
                    if (selectedRow >= 0) {
                        displayOrderedDrinks(selectedRow + 1);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Please select an order to view.");
                    }
                }
            });
    
            panel.add(scrollPane, BorderLayout.CENTER);
            panel.add(viewOrderButton, BorderLayout.SOUTH);
    
            JOptionPane.showMessageDialog(frame, panel, "All Orders", JOptionPane.INFORMATION_MESSAGE);
            showAdminMenu();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "No orders available.");
        }
    }
    
    private static void displayOrderedDrinks(int orderNumber) {
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            int currentOrder = 1;
            boolean foundOrder = false;
            StringBuilder orderedDetails = new StringBuilder();
    
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Ordered Drinks:") && currentOrder == orderNumber) {
                    foundOrder = true;
                    orderedDetails.append(line).append("\n");
                    while ((line = reader.readLine()) != null && !line.startsWith("Total Cost:")) {
                        orderedDetails.append(line).append("\n");
                    }
                    break;
                } else if (line.startsWith("Total Cost:")) {
                    currentOrder++;
                }
            }
    
            if (foundOrder) {
                // Display the selected order details
                String ratingLine = reader.readLine(); // Read the rating line
                if (ratingLine != null && ratingLine.startsWith("Rating:")) {
                    orderedDetails.append(ratingLine).append("\n");
                }
                
                JOptionPane.showMessageDialog(frame,
                        orderedDetails.toString(),
                        "Selected Order", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(frame, "Order not found.");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error reading order details.");
        }
    }    

    private static void generateReports() {
        String[] reportOptions = {
            "Top 3 Popular Drinks",
            "Highest Profit Drink",
            "Highest Amount Per Sales",
            "Average Rating of System"
        };
    
        int selectedReport = JOptionPane.showOptionDialog(
            frame,
            "Select a report to generate:",
            "Generate Reports",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.PLAIN_MESSAGE,
            null,
            reportOptions,
            reportOptions[0]
        );
    
        switch (selectedReport) {
            case 0:
                generateTop3PopularDrinksReport();
                break;
            case 1:
                generateHighestProfitDrinkReport();
                break;
            case 2:
                generateHighestAmountPerSalesReport();
                break;
            case 3:
                generateAverageRatingReport();
                break;
        }
    }
        

    private static void generateTop3PopularDrinksReport() {
        Map<String, Integer> drinkQuantities = new HashMap<>();
        Map<String, Double> drinkPrices = new HashMap<>();
    
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Ordered Drinks:")) {
                    while ((line = reader.readLine()) != null && !line.isEmpty()) {
                        if (line.startsWith("Total Cost:")) {
                            break; // Ignore Total Cost lines
                        }
                        // Split the drink line into parts based on ": " or " x "
                        String[] drinkParts = line.split(": | x ");
                        if (drinkParts.length == 3) {
                            String drinkName = drinkParts[0];
                            int quantity = Integer.parseInt(drinkParts[1]);
                            double price = Double.parseDouble(drinkParts[2].substring(1));
    
                            // Update drink quantities and prices in the maps
                            drinkQuantities.put(drinkName, drinkQuantities.getOrDefault(drinkName, 0) + quantity);
                            drinkPrices.put(drinkName, price);
                        }
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "No orders available.");
        }
    
        PriorityQueue<DrinkInfo> topDrinks = new PriorityQueue<>(3, Collections.reverseOrder());
    
        for (Map.Entry<String, Integer> entry : drinkQuantities.entrySet()) {
            String drinkName = entry.getKey();
            int quantity = entry.getValue();
            double price = drinkPrices.getOrDefault(drinkName, 0.0);
    
            DrinkInfo drinkInfo = new DrinkInfo(drinkName, quantity, price);
            topDrinks.offer(drinkInfo);
        }

        Font reportFont = new Font("Arial", Font.PLAIN, 18);
    
        if (!topDrinks.isEmpty()) {
            StringBuilder report = new StringBuilder("Top 3 Popular Drinks Report:\n\n");
            for (int i = 0; i < 3 && !topDrinks.isEmpty(); i++) {
                DrinkInfo drinkInfo = topDrinks.poll();
                double totalSales = drinkInfo.price * drinkInfo.quantity;
                
                report.append("\n");
                report.append("Drink: ").append(drinkInfo.name).append("\n");
                report.append("Total Quantity: ").append(drinkInfo.quantity).append("\n");
                report.append("Total Sales: $").append(totalSales).append("\n");
                report.append("\n--------------------------");
            }
            JTextArea textArea = new JTextArea(report.toString());
            textArea.setFont(reportFont);
            textArea.setEditable(false);
            
            JScrollPane scrollPane = new JScrollPane(textArea);
    
            JOptionPane.showMessageDialog(frame, scrollPane, "Top 3 Popular Drinks Report", JOptionPane.INFORMATION_MESSAGE);
            showAdminMenu();
        } else {
            JOptionPane.showMessageDialog(frame, "No data available for the top popular drinks.", "Top 3 Popular Drinks Report", JOptionPane.INFORMATION_MESSAGE);
            showAdminMenu();
        }
    }
    
    private static class DrinkInfo implements Comparable<DrinkInfo> {
        String name;
        int quantity;
        double price;
    
        public DrinkInfo(String name, int quantity, double price) {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }
    
        @Override
        public int compareTo(DrinkInfo other) {
            return Integer.compare(this.quantity, other.quantity);
        }
    }
    
        
    
    private static void generateHighestProfitDrinkReport() {
        List<String> orderLines = new ArrayList<>();
        Map<String, Double> drinkPrices = new HashMap<>();
        Map<String, Integer> drinkQuantities = new HashMap<>();
        Font reportFont = new Font("Arial", Font.PLAIN, 18);
        
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Ordered Drinks:")) {
                    while ((line = reader.readLine()) != null && !line.isEmpty()) {
                        if (line.startsWith("Total Cost:")) {
                            break; // Ignore Total Cost lines
                        }
                        // Split the drink line into parts based on ": " or " x "
                        String[] drinkParts = line.split(": | x ");
                        if (drinkParts.length == 3) {
                            String drinkName = drinkParts[0];
                            int quantity = Integer.parseInt(drinkParts[1]);
                            double price = Double.parseDouble(drinkParts[2].substring(1));
                            
                            // Update drink quantities and prices in the maps
                            drinkQuantities.put(drinkName, drinkQuantities.getOrDefault(drinkName, 0) + quantity);
                            drinkPrices.put(drinkName, price);
                        }
                    }
                }
                orderLines.add(line); // Store the line in the orderLines list
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "No orders available.");
            showAdminMenu();
            return;
        }
    
        double highestProfit = 0;
        String highestProfitDrink = "";
    
        for (Map.Entry<String, Double> entry : drinkPrices.entrySet()) {
            String drinkName = entry.getKey();
            double price = entry.getValue();
            int quantity = drinkQuantities.getOrDefault(drinkName, 0);
    
            double profit = price * quantity;
            if (profit > highestProfit) {
                highestProfit = profit;
                highestProfitDrink = drinkName;
            }
        }
    
        if (!highestProfitDrink.isEmpty()) {
            double highestProfitValue = drinkPrices.getOrDefault(highestProfitDrink, 0.0) * drinkQuantities.getOrDefault(highestProfitDrink, 0);
    
            StringBuilder report = new StringBuilder("Highest Profit Drink Report:\n\n");
            report.append("Drink: ").append(highestProfitDrink).append("\n");
            report.append("Total Quantity Sold: ").append(drinkQuantities.getOrDefault(highestProfitDrink, 0)).append("\n");
            report.append("Total Profit: $").append(highestProfitValue).append("\n");
    
            JTextArea textArea = new JTextArea(report.toString());
            textArea.setFont(reportFont);
            textArea.setEditable(false);
            
            JScrollPane scrollPane = new JScrollPane(textArea);

            JOptionPane.showMessageDialog(frame, scrollPane, "Highest Profit Drink Report", JOptionPane.INFORMATION_MESSAGE);
            showAdminMenu();
        } else {
            JOptionPane.showMessageDialog(frame, "No data available for the highest profit drink.", "Highest Profit Drink Report", JOptionPane.INFORMATION_MESSAGE);
            showAdminMenu();
        }
    }

    private static void generateHighestAmountPerSalesReport() {
        double highestAmount = 0.0;
        String highestAmountOrder = "";
        Font reportFont = new Font("Arial", Font.PLAIN, 18);
    
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            StringBuilder currentOrder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Ordered Drinks:")) {
                    currentOrder.setLength(0); // Clear the current order details
                }
                currentOrder.append(line).append("\n"); // Append each line to the current order
                if (line.startsWith("Total Cost:")) {
                    String amountString = line.substring(12).replaceAll("[^0-9.]", ""); // Extract numeric characters
                    double amount = Double.parseDouble(amountString); // Parse the amount
                    if (amount > highestAmount) {
                        highestAmount = amount;
                        highestAmountOrder = currentOrder.toString(); // Store the entire current order
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "No orders available.");
            showAdminMenu();
            return;
        }
    
        if (!highestAmountOrder.isEmpty()) {
            StringBuilder report = new StringBuilder("Highest Amount Per Sales Report:\n\n");
            report.append("Order Details:\n\n");
            report.append(highestAmountOrder).append("\n");
    
            JTextArea textArea = new JTextArea(report.toString());
            textArea.setFont(reportFont);
            textArea.setEditable(false);
            
            JScrollPane scrollPane = new JScrollPane(textArea);

            JOptionPane.showMessageDialog(frame, scrollPane, "Highest Amount Per Sales Report", JOptionPane.INFORMATION_MESSAGE);
            showAdminMenu();
        } else {
            JOptionPane.showMessageDialog(frame, "No data available for the highest amount per sales.", "Highest Amount Per Sales Report", JOptionPane.INFORMATION_MESSAGE);
            showAdminMenu();
        }
    }

    private static void generateAverageRatingReport() {
        int totalRating = 0;
        int numberOfRatings = 0;
        
        try (BufferedReader reader = new BufferedReader(new FileReader("orders.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Rating:")) {
                    int rating = getRatingFromLine(line);
                    totalRating += rating;
                    numberOfRatings++;
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "No orders available.");
            showAdminMenu();
            return;
        }
    
        if (numberOfRatings == 0) {
            JOptionPane.showMessageDialog(frame, "No ratings available.", "Average Rating Report", JOptionPane.INFORMATION_MESSAGE);
            showAdminMenu();
            return;
        }
    
        double averageRating = (double) totalRating / numberOfRatings;
        String report = String.format("Average Rating: %.2f", averageRating);
    
        Font reportFont = new Font("Arial", Font.PLAIN, 18);
        JTextArea textArea = new JTextArea(report);
        textArea.setFont(reportFont);
        textArea.setEditable(false);
    
        JScrollPane scrollPane = new JScrollPane(textArea);
        
        JOptionPane.showMessageDialog(frame, scrollPane, "Average Rating Report", JOptionPane.INFORMATION_MESSAGE);
        showAdminMenu();
    }    
    
    private static int getRatingFromLine(String line) {
        int count = 0;
        for (char c : line.toCharArray()) {
            if (c == '*') {
                count++;
            }
        }
        return count;
    }

private static void showAccountManagementPanel() {
    JPanel accountManagementPanel = new JPanel(new BorderLayout());

    // Load the admin accounts data from staff.txt
    List<AdminAccount> adminAccounts = loadAdminAccounts();

    // Create a table to display the admin accounts
    JTable accountsTable = createAccountsTable(adminAccounts);
    JScrollPane scrollPane = new JScrollPane(accountsTable);
    accountManagementPanel.add(scrollPane, BorderLayout.CENTER);

    String[] accountOptions = {
        "Add Account",
        "Edit Account",
        "Delete Account",
        "Back"
    };

    int accountChoice = JOptionPane.showOptionDialog(frame,
            accountManagementPanel,
            "Account Management",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.PLAIN_MESSAGE,
            null,
            accountOptions,
            accountOptions[0]
    );

    switch (accountChoice) {
        case 0: // Add Account
            addAccount(adminAccounts, accountsTable);
            break;
        case 1: // Edit Account
            editAccount(adminAccounts, accountsTable);
            break;
        case 2: // Delete Account
            deleteAccount(adminAccounts, accountsTable);
            break;
        case 3: // Back
            break;
    }

    // After handling the account management option, show the main admin menu again
    showAdminMenu();
}

private static List<AdminAccount> loadAdminAccounts() {
    List<AdminAccount> adminAccounts = new ArrayList<>();
    try (BufferedReader reader = new BufferedReader(new FileReader(STAFF_FILE))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length >= 2) {
                adminAccounts.add(new AdminAccount(parts[0], parts[1]));
            }
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(frame, "Error loading admin accounts data.");
    }
    return adminAccounts;
}

private static JTable createAccountsTable(List<AdminAccount> adminAccounts) {
    String[] columnNames = {"Username", "Password"};
    Object[][] data = new Object[adminAccounts.size()][2];

    for (int i = 0; i < adminAccounts.size(); i++) {
        AdminAccount adminAccount = adminAccounts.get(i);
        data[i][0] = adminAccount.getUsername();
        data[i][1] = adminAccount.getPassword();
    }

    DefaultTableModel model = new DefaultTableModel(data, columnNames) {
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return String.class; // Set column class to String for all columns
        }
    };

    JTable table = new JTable(model);

    // Center-align the cells in all columns
    DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(JLabel.CENTER);
    table.setDefaultRenderer(String.class, centerRenderer);

    // Enhance visual styling
    table.setRowHeight(30);
    table.setFont(new Font("Arial", Font.PLAIN, 16));

    // Set table header font and style
    JTableHeader tableHeader = table.getTableHeader();
    tableHeader.setFont(new Font("Arial", Font.BOLD, 18));

    // Adjust column widths
    TableColumnModel columnModel = table.getColumnModel();
    columnModel.getColumn(0).setPreferredWidth(150); // Adjust the preferred width of columns
    columnModel.getColumn(1).setPreferredWidth(100);

    return table;
}



private static void addAccount(List<AdminAccount> adminAccounts, JTable accountsTable) {
    String username = JOptionPane.showInputDialog(frame, "Enter username:");
    String password = JOptionPane.showInputDialog(frame, "Enter password:");

    if (username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
        adminAccounts.add(new AdminAccount(username, password));
        saveAdminAccounts(adminAccounts);
        updateTableData(accountsTable, adminAccounts);
        showAccountManagementPanel();
    } else {
        JOptionPane.showMessageDialog(frame, "Please enter valid username and password.");
        showAccountManagementPanel();
    }
}

private static void editAccount(List<AdminAccount> adminAccounts, JTable accountsTable) {
    int selectedRow = accountsTable.getSelectedRow();

    if (selectedRow >= 0) {
        AdminAccount selectedAccount = adminAccounts.get(selectedRow);
        String newUsername = JOptionPane.showInputDialog(frame, "Enter new username:", selectedAccount.getUsername());
        String newPassword = JOptionPane.showInputDialog(frame, "Enter new password:", selectedAccount.getPassword());

        if (newUsername != null && !newUsername.isEmpty() && newPassword != null && !newPassword.isEmpty()) {
            selectedAccount.setUsername(newUsername);
            selectedAccount.setPassword(newPassword);
            saveAdminAccounts(adminAccounts);
            updateTableData(accountsTable, adminAccounts);
            showAccountManagementPanel();
        } else {
            JOptionPane.showMessageDialog(frame, "Please enter valid username and password.");
            showAccountManagementPanel();
        }
    } else {
        JOptionPane.showMessageDialog(frame, "Please select an account to edit.");
        showAccountManagementPanel();
    }
}

private static void deleteAccount(List<AdminAccount> adminAccounts, JTable accountsTable) {
    int selectedRow = accountsTable.getSelectedRow();

    if (selectedRow >= 0) {
        adminAccounts.remove(selectedRow);
        saveAdminAccounts(adminAccounts);
        updateTableData(accountsTable, adminAccounts);
        showAccountManagementPanel();
    } else {
        JOptionPane.showMessageDialog(frame, "Please select an account to delete.");
        showAccountManagementPanel();
    }
}

private static void saveAdminAccounts(List<AdminAccount> adminAccounts) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(STAFF_FILE))) {
        for (AdminAccount adminAccount : adminAccounts) {
            writer.write(adminAccount.getUsername() + "," + adminAccount.getPassword());
            writer.newLine();
        }
    } catch (IOException e) {
        JOptionPane.showMessageDialog(frame, "Error saving admin accounts data.");
    }
}

private static void updateTableData(JTable accountsTable, List<AdminAccount> adminAccounts) {
    DefaultTableModel model = (DefaultTableModel) accountsTable.getModel();
    model.setRowCount(0);
    
    for (AdminAccount adminAccount : adminAccounts) {
        model.addRow(new Object[]{adminAccount.getUsername(), adminAccount.getPassword()});
    }
}
    
    private static void loadDrinksData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(DRINKS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0];
                double price = Double.parseDouble(parts[1]);
                int quantity = Integer.parseInt(parts[2]);
                drinksList.add(new Drink(name, price, quantity)); // Add to drinksList
            }
        } catch (IOException e) {
            System.out.println("Error loading drinks data.");
        }
    }
}


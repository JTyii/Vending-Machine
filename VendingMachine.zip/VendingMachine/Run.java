import javax.swing.SwingUtilities;

public class Run {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            VendingMachineGUI.loadDrinksData();
            VendingMachineGUI.createAndShowGUI();
            logActivity.logSystemStartActivity();
        });
    }
}

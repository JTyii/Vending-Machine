import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

public class logActivity {
    static void logSystemStartActivity() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("log.txt", true))) {
            String logEntry = "[" + new Date() + "] " + "SYSTEM-START\n";
            writer.write(logEntry);
        } catch (IOException e) {
            System.out.println("Error logging system activity.");
        }
    }

    static void logGuestLoginActivity() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("log.txt", true))) {
            String logEntry = "[" + new Date() + "] " + "guest logged in\n";
            writer.write(logEntry);
        } catch (IOException e) {
            System.out.println("Error logging login activity.");
        }
    }

    static void logPaymentActivity() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("log.txt", true))) {
            String logEntry = "[" + new Date() + "] " + "payment made\n";
            writer.write(logEntry);
        } catch (IOException e) {
            System.out.println("Error logging payment activity.");
        }
    }

    static void logSystemEndActivity() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("log.txt", true))) {
            String logEntry = "[" + new Date() + "] " + "SYSTEM-END\n";
            writer.write(logEntry);
        } catch (IOException e) {
            System.out.println("Error logging system activity.");
        }
    }

    static void logAdminLoginActivity(String username) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("log.txt", true))) {
            String logEntry = "[" + new Date() + "] " + username + " logged in\n";
            writer.write(logEntry);
        } catch (IOException e) {
            System.out.println("Error logging login activity.");
        }
    }
}

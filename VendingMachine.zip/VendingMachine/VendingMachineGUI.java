import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.WindowEvent;

public class VendingMachineGUI {
    private static final String DRINKS_FILE = "drinks.txt";
    private static List<Drink> drinksList = new ArrayList<>();
    private static JFrame frame;
    private static JPanel drinkPanel;
    private static JPanel orderedPanel;
    private static JButton confirmPurchaseButton;
    private static List<Drink> orderedDrinks = new ArrayList<>();
    private static JLabel totalCostLabel;
    private static List<JToggleButton> starButtons = new ArrayList<>(); // Added starButtons list

    private static String getCurrentDate() {
    LocalDate currentDate = LocalDate.now();
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    return formatter.format(currentDate);
}
    static void createAndShowGUI() {
        logActivity.logGuestLoginActivity();
        JFrame frame = new JFrame("Vending Machine");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 700);
        frame.setLayout(new BorderLayout());
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                logActivity.logSystemEndActivity();
                System.exit(0); // Exit the application
            }
        });
    
        JPanel topPanel = new JPanel(new BorderLayout());
    
        JButton adminButton = new JButton("ADMIN");
        adminButton.setFont(new Font("Arial", Font.BOLD, 14));
        adminButton.setPreferredSize(new Dimension(150, 30));

        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a password field for input
                JPasswordField passwordField = new JPasswordField();
                
                // Show the input dialog with the password field
                int option = JOptionPane.showConfirmDialog(frame, passwordField, "Enter Secret Password:", JOptionPane.OK_CANCEL_OPTION);
        
                // Check the user's input
                if (option == JOptionPane.OK_OPTION) {
                    String inputPassword = new String(passwordField.getPassword());
                    if ("iamadmin".equals(inputPassword)) {
                        frame.dispose(); // Close the main window
                        new Admin(); // Launch the Admin class
                    } else {
                        JOptionPane.showMessageDialog(frame, "Incorrect password.");
                    }
                }
            }
        });
        topPanel.add(adminButton, BorderLayout.WEST);

    // Set up a color scheme
    Color backgroundColor = new Color(240, 240, 240);
    Color buttonTextColor = Color.black;

    Font datetimeFont = new Font("Arial", Font.PLAIN, 15);
    JLabel datetimeLabel = new JLabel(getCurrentDate());
    datetimeLabel.setFont(datetimeFont);
    topPanel.add(datetimeLabel, BorderLayout.EAST);
    
    JPanel ratingPanel = new JPanel();
    ratingPanel.setLayout(new FlowLayout());
    ratingPanel.setBackground(backgroundColor);

    // Create the star rating components and add them to the list
    for (int i = 1; i <= 5; i++) {
        ImageIcon starIcon = new ImageIcon("img/star.png"); 
        JToggleButton starButton = new JToggleButton(starIcon);
        starButton.setPreferredSize(new Dimension(30, 30));
        starButton.setBackground(backgroundColor);
        starButton.setFocusPainted(false);
        starButtons.add(starButton);
        ratingPanel.add(starButton);
    }

    // Add a listener to the star buttons
    for (JToggleButton starButton : starButtons) {
        starButton.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int clickedIndex = starButtons.indexOf(starButton);
                for (int i = 0; i <= clickedIndex; i++) {
                    starButtons.get(i).setSelected(starButton.isSelected());
                }
            }
        });
    }

    frame.add(topPanel, BorderLayout.NORTH);
    topPanel.add(ratingPanel, BorderLayout.CENTER);

    TitledBorder menuBorder = BorderFactory.createTitledBorder(
        BorderFactory.createLineBorder(Color.BLACK, 3), // Add a black border line
        "Menu",
        TitledBorder.CENTER,
        TitledBorder.TOP
    );
    TitledBorder orderedListBorder = BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(Color.BLACK, 3), // Add a black border line
            "Ordered List",
            TitledBorder.CENTER,
            TitledBorder.TOP
    );

    drinkPanel = new JPanel();
    drinkPanel.setBorder(menuBorder);
    drinkPanel.setLayout(new GridLayout(drinksList.size(), 1));

    orderedPanel = new JPanel();
    orderedPanel.setBorder(orderedListBorder);
    orderedPanel.setLayout(new BoxLayout(orderedPanel, BoxLayout.Y_AXIS));

    Font titleFont = new Font("Arial", Font.BOLD, 20);
    Font buttonFont = new Font("Arial", Font.BOLD, 16);

    menuBorder.setTitleFont(titleFont);
    menuBorder.setTitleJustification(TitledBorder.CENTER);

    orderedListBorder.setTitleFont(titleFont);
    orderedListBorder.setTitleJustification(TitledBorder.CENTER);
    orderedPanel.setBorder(orderedListBorder);

    // Create a JLabel for the total cost label with proper font and alignment
    totalCostLabel = new JLabel("Total Cost: $0.00");
    totalCostLabel.setFont(buttonFont);
    totalCostLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Align center horizontally
    orderedPanel.add(totalCostLabel);

    confirmPurchaseButton = new JButton("Confirm Purchase");
    confirmPurchaseButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            handleConfirmPurchase();
        }
    });
    
    for (Drink drink : drinksList) {
        JButton drinkButton;
        if (drink.quantity > 0) {
            drinkButton = new JButton(drink.name + " ($" + drink.price + ") - Qty: " + drink.quantity);
        } else {
            JButton soldOutButton = new JButton(drink.name + " - Sold Out");
            soldOutButton.setEnabled(false);
            soldOutButton.setFont(buttonFont);
            soldOutButton.setBackground(Color.GRAY); // You can choose another color for the sold-out buttons
            soldOutButton.setForeground(buttonTextColor);
            drinkButton = soldOutButton;
        }
        drinkButton.setFont(buttonFont);
        drinkButton.setForeground(buttonTextColor);
        drinkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleCustomerDrinkSelection(drink);
            }
        });
        drinkPanel.add(drinkButton);
    }

    JPanel rightPanel = new JPanel();
    rightPanel.setLayout(new BorderLayout());
    rightPanel.add(orderedPanel, BorderLayout.CENTER);
    
    JPanel buttonsPanel = new JPanel();
    buttonsPanel.setLayout(new GridLayout(2, 1));
    buttonsPanel.setBackground(backgroundColor);

    JButton cancelOrderButton = new JButton("Cancel Order");
    cancelOrderButton.setFont(buttonFont);
    cancelOrderButton.setBackground(Color.RED); 
    cancelOrderButton.setForeground(buttonTextColor);
    cancelOrderButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            handleCancelOrder();
        }
    });
    buttonsPanel.add(cancelOrderButton);

    confirmPurchaseButton.setFont(buttonFont);
    confirmPurchaseButton.setBackground(Color.GREEN); 
    confirmPurchaseButton.setForeground(buttonTextColor);
    buttonsPanel.add(confirmPurchaseButton);

    rightPanel.add(buttonsPanel, BorderLayout.SOUTH);

    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, drinkPanel, rightPanel);
    splitPane.setDividerLocation(400);

    frame.getContentPane().setBackground(backgroundColor);
    orderedPanel.setBackground(backgroundColor);
    drinkPanel.setBackground(backgroundColor);

    frame.add(splitPane, BorderLayout.CENTER);
    frame.setVisible(true);
    }

    private static void refreshDrinkButtons() {
        Color backgroundColor = new Color(240, 240, 240);
        Color buttonTextColor = Color.black;
    
        drinkPanel.removeAll();
        drinkPanel.setLayout(new GridLayout(drinksList.size(), 1));
    
        Font buttonFont = new Font("Arial", Font.BOLD, 16);
    
        for (Drink drink : drinksList) {
        JButton drinkButton;
        if (drink.quantity > 0) {
            drinkButton = new JButton(drink.name + " ($" + drink.price + ") - Qty: " + drink.quantity);
        } else {
            JButton soldOutButton = new JButton(drink.name + " - Sold Out");
            soldOutButton.setEnabled(false);
            soldOutButton.setFont(buttonFont);
            soldOutButton.setBackground(Color.GRAY); 
            soldOutButton.setForeground(buttonTextColor);
            drinkButton = soldOutButton;
        }
        drinkButton.setFont(buttonFont);
        drinkButton.setForeground(buttonTextColor);
        drinkButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                handleCustomerDrinkSelection(drink);
            }
        });
        drinkPanel.add(drinkButton);
    }
    
        drinkPanel.setBackground(backgroundColor); // Set the background color
        frame.revalidate();
        frame.repaint();
    }    
    
    private static double handlePaymentInput(double totalCost) {
        String paymentStr = JOptionPane.showInputDialog(frame, "Enter the amount paid:");
        try {
            double payment = Double.parseDouble(paymentStr);
            if (payment < totalCost) {
                JOptionPane.showMessageDialog(frame, "Amount paid is insufficient.");
                return handlePaymentInput(totalCost); // Ask again if the payment is insufficient
            } else {
                return payment;
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Invalid amount. Please enter a valid number.");
            return handlePaymentInput(totalCost); // Ask again if input is not a valid number
        }
    }    
    
    private static void handleConfirmPurchase() {
        if (orderedDrinks.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No drinks ordered.");
            return;
        }
    
        double totalCost = 0.0;
        for (Drink orderedDrink : orderedDrinks) {
            totalCost += orderedDrink.price * orderedDrink.quantity;
        }
    
        double payment = handlePaymentInput(totalCost);
    
        int confirm = JOptionPane.showConfirmDialog(frame, "Total price: $" + totalCost +
                "\nAmount paid: $" + payment +
                "\nConfirm purchase?", "Confirm Purchase", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            int selectedRating = 0;
            for (JToggleButton starButton : starButtons) {
                if (starButton.isSelected()) {
                    selectedRating = starButtons.indexOf(starButton) + 1;
                    break;
                }
            }

            if (selectedRating == 0) {
                JOptionPane.showMessageDialog(frame, "Please select a rating before confirming the purchase.");
                return;
            }
            double balance = payment - totalCost;
    
            for (Drink orderedDrink : orderedDrinks) {
                for (Drink drink : drinksList) {
                    if (drink.name.equals(orderedDrink.name)) {
                        if (drink.quantity < 0) {
                            drink.quantity = 0; // Make sure quantity does not go negative
                        }
                        break;
                    }
                }
            }
    
            JOptionPane.showMessageDialog(frame, "Purchase successful. Receipt will be generated.");
            saveDrinksData();
            generateReceipt(orderedDrinks, totalCost, payment, balance);
            logActivity.logPaymentActivity();
            saveOrderToFile(orderedDrinks, totalCost); // Save the order to the file
            for (JToggleButton starButton : starButtons) {
            starButton.setSelected(false);
            }
            orderedDrinks.clear(); // Clear ordered drinks
            updateOrderedPanel();
            refreshDrinkButtons();
        }
    }    
    

    private static void saveDrinksData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DRINKS_FILE))) {
            for (Drink drink : drinksList) {
                writer.write(drink.name + "," + drink.price + "," + drink.quantity);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error updating drinks data.");
        }
    }
    

    private static void handleCustomerDrinkSelection(Drink selectedDrink) {
    String quantityStr = JOptionPane.showInputDialog(frame, "Enter quantity:");
    try {
        int quantity = Integer.parseInt(quantityStr);
        if (quantity <= 0) {
            JOptionPane.showMessageDialog(frame, "Invalid quantity. Please enter a positive value.");
        } else {
            // Find the corresponding drink object from drinksList
            for (Drink drink : drinksList) {
                if (drink.name.equals(selectedDrink.name)) {
                    if (quantity > drink.quantity) {
                        JOptionPane.showMessageDialog(frame, "Insufficient quantity available.");
                    } else {
                        orderedDrinks.add(new Drink(drink.name, drink.price, quantity));
                        updateOrderedPanel();

                        // Deduct the ordered quantity from the drink's quantity
                        drink.quantity -= quantity;

                        refreshDrinkButtons(); // Update the drink buttons with remaining quantities
                    }
                    return; // Exit the loop once the correct drink is found
                }
            }
        }
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(frame, "Invalid quantity. Please enter a valid number.");
    }
}    

    private static void handleCancelOrder() {
        for (Drink orderedDrink : orderedDrinks) {
            for (Drink drink : drinksList) {
                if (drink.name.equals(orderedDrink.name)) {
                    drink.quantity += orderedDrink.quantity;
                    break;
                }
            }
        }
    
        orderedDrinks.clear(); // Clear ordered drinks
        updateOrderedPanel();
        refreshDrinkButtons(); // Update the drink buttons with restored quantities
    }
    

    private static void updateOrderedPanel() {
        orderedPanel.removeAll();
    
        Font totalFont = new Font("Arial", Font.BOLD, 16);
        Font orderedListFont = new Font("Arial", Font.PLAIN, 14);
        
        double totalCost = 0.0;
        for (Drink orderedDrink : orderedDrinks) {
            JLabel orderedLabel = new JLabel(orderedDrink.name + " - $" + orderedDrink.price + " x " + orderedDrink.quantity);
            orderedLabel.setFont(orderedListFont);
            orderedLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Align center horizontally
            orderedPanel.add(orderedLabel);
            totalCost += orderedDrink.price * orderedDrink.quantity;
        }
    
        // Create a separator using an HTML formatted label
        JLabel separatorLabel = new JLabel("---------------------------------------");
        separatorLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Align center horizontally
        orderedPanel.add(separatorLabel);
    
        totalCostLabel.setText("Total Cost: $" + String.format("%.2f", totalCost)); // Update total cost label
        totalCostLabel.setFont(totalFont);
        totalCostLabel.setAlignmentX(Component.CENTER_ALIGNMENT); // Align center horizontally
        orderedPanel.add(totalCostLabel);
    
        orderedPanel.revalidate();
        orderedPanel.repaint();
    }

    
    private static void generateReceipt(List<Drink> orderedDrinks, double totalCost, double payment, double balance) {
        StringBuilder receiptMessage = new StringBuilder("Receipt\n\n");
        for (Drink orderedDrink : orderedDrinks) {
            receiptMessage.append("Drink: ").append(orderedDrink.name).append("\n");
            receiptMessage.append("Quantity: ").append(orderedDrink.quantity).append("\n");
            receiptMessage.append("Total Price: $").append(orderedDrink.price * orderedDrink.quantity).append("\n\n");
        }
        receiptMessage.append("--------------------------------------\n");
        receiptMessage.append("Total Cost: $").append(totalCost).append("\n");
        receiptMessage.append("Amount Paid: $").append(payment).append("\n");
        receiptMessage.append("Balance: $").append(balance).append("\n\n");
        receiptMessage.append("Thank you for your purchase!\n");
    
        int selectedRating = 0;
        for (JToggleButton starButton : starButtons) {
            if (starButton.isSelected()) {
                selectedRating++;
            }
        }
    
        receiptMessage.append("Rating: ");
        for (int i = 1; i <= selectedRating; i++) {
            receiptMessage.append("\u2605"); // Add solid stars based on the selected rating
        }
        receiptMessage.append(" (" + selectedRating + " stars)\n");
    
        JOptionPane.showMessageDialog(frame, receiptMessage.toString(), "Receipt", JOptionPane.INFORMATION_MESSAGE);
    }    

    private static void saveOrderToFile(List<Drink> orderedDrinks, double totalCost) {
        int selectedRating = 0;
        for (JToggleButton starButton : starButtons) {
            if (starButton.isSelected()) {
                selectedRating++;
            }
        }
    
        StringBuilder orderText = new StringBuilder("Ordered Drinks:\n");
        for (Drink orderedDrink : orderedDrinks) {
            orderText.append(orderedDrink.name).append(": ").append(orderedDrink.quantity).append(" x $").append(orderedDrink.price).append("\n");
        }
        orderText.append("Total Cost: $").append(totalCost).append("\n");
        orderText.append("Rating: ");
        
        for (int i = 1; i <= selectedRating; i++) {
            orderText.append("*"); // Use asterisk instead of the solid star
        }
        orderText.append(" (" + selectedRating + " stars)\n\n");
    
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("orders.txt", true))) {
            writer.write(orderText.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saving order.");
        }
    }
       
        
    static void loadDrinksData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(DRINKS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0];
                double price = Double.parseDouble(parts[1]);
                int quantity = Integer.parseInt(parts[2]);
                drinksList.add(new Drink(name, price, quantity));
            }
        } catch (IOException e) {
            System.out.println("Error loading drinks data.");
        }
    }
}
